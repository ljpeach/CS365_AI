﻿# This is the readme for lab 1

For this lab, argparse is imported for each script.
To run the code, run `python script_name.py -i maze_name.txt` under the uncompressed directory.

E.g. `python single_gbfs.py -i 1prize_large.txt`
<br/>
The result, including the output maze trace, cost and node expanded will also be printed.

---

note: The symbol represents the mouse ("P") will always be on the position of the last prize it visited, after running each script.

E.g. In a maze with 12 prizes, the last position of the prize printed in the maze will be the mouse "P", instead of the symbol "c".
  
  
